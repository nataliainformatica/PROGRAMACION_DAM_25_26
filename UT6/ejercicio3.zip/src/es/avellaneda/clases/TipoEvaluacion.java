package es.avellaneda.clases;

public enum TipoEvaluacion {
PRIMERA, 
SEGUNDA, 
TERCERA, 
ORDINARIA, 
EXTRAORDINARIA
}
