package es.avellaneda.clases;

/**
 * 
 * tipo (Enum): Tipo de evaluación (Primera, Segunda, Tercera, Ordinaria,
 * Extraordinaria).
 * 
 * calificacion (double): Nota obtenida.
 * 
 * 
 */
public class Nota {

    private TipoEvaluacion tipoEvaluacion; 
    private double calificacion;
    
    public Nota(TipoEvaluacion tipoEvaluacion, double calificacion) {
        this.tipoEvaluacion = tipoEvaluacion;
        this.calificacion = calificacion;
    }
    public TipoEvaluacion getTipoEvaluacion() {
        return tipoEvaluacion;
    }
    public void setTipoEvaluacion(TipoEvaluacion tipoEvaluacion) {
        this.tipoEvaluacion = tipoEvaluacion;
    }
    public double getCalificacion() {
        return calificacion;
    }
    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }
    @Override
    public String toString() {
        return "Nota [tipoEvaluacion=" + tipoEvaluacion + ", calificacion=" + calificacion + "]";
    }

    

    

    



}
