package es.avellaneda.clases;

import java.util.Arrays;

/**
 * nombre (String): Nombre completo del alumno.

matricula (String): Número de matrícula único del alumno.

modulos (Array de Módulos): Lista de módulos en los que está inscrito el alumno.
 */
public class Alumno {

    private String nombre; 
    private String matricula; 
    private Modulo[] modulos;
    private final int MAX =7; 
    private int contador; 


    
    public Alumno(String nombre, String matricula) {
        this.nombre = nombre;
        this.matricula = matricula;
        this.modulos = new Modulo[MAX]; 
        this.contador = 0; 

    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    @Override
    public String toString() {
        return "Alumno [nombre=" + nombre + ", matricula=" 
        + matricula + ", modulos=" + Arrays.toString(modulos)
                +  "]";
    } 

    //agregarModulo y mostrarInformacion.

    public boolean addModulo(Modulo modulo){

        if(contador >= modulos.length){
            return false; 
        }
        modulos[contador] = modulo;
        contador ++;

        return true; 

    }

    public String mostrarInformacion(){
            // solo mostrará los módulos que tenga, y no valores nulos

            StringBuilder sb = new StringBuilder(); 
            sb.append("nombre " + nombre); 
            sb.append("matricula" + matricula); 
            for(Modulo m: modulos){
                if (m!= null){
                    sb.append("Modulo" + m.getNombre());
                }
            }
            return sb.toString(); 

    }
    
    

}
