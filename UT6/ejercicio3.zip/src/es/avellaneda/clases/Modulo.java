package es.avellaneda.clases;

import java.util.Arrays;

/**
 * nombre (String): Nombre del módulo (por ejemplo, "Programación").
 * 
 * codigo (String): Código único del módulo.
 * 
 * notas (Array de Notas): Lista de las evaluaciones (primera, segunda, tercera,
 * ordinaria y extradinaria) del módulo.
 */
public class Modulo {

    private String nombre;
    private String codigo;
    private Nota[] notas;

    public Modulo(String nombre, String codigo) {
        this.nombre = nombre;
        this.codigo = codigo;
        notas = new Nota[5];
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Modulo [nombre=" + nombre + ", codigo=" + codigo + ", notas=" + Arrays.toString(notas) + "]";
    }

    public void insertarNota(Nota nota){
        //   dependiendo del tipo, lo incluye en la posición de la evaluación correspondiente  }
        switch (nota.getTipoEvaluacion()) {
            case PRIMERA:
                notas[0]= nota; 
                break;
            case SEGUNDA: 
                notas[1]=nota; 
                break; 
            case TERCERA:
                notas[2]= nota; 
                break;
            case ORDINARIA:
                notas[3]= nota; 
                break;
            case EXTRAORDINARIA:
                notas[4]= nota; 
                break;
            default:
                break;
        }
    }
    public double calcularNotaMedia(){
        double notaMedia =0;
        int contador =0; 
        for(int i=0;i<3; i++){
            if(notas[i]!=null){
            contador++; 
            notaMedia += notas[i].getCalificacion();
            }
        }
        return notaMedia/contador; 
    }   

    
    // Métodos: Constructor para inicializar los atributos.
    // Métodos para agregar una
    // nota y calcular la nota media.

}
