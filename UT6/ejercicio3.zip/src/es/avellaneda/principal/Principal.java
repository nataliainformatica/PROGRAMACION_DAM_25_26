package es.avellaneda.principal;

import java.util.Scanner;

import es.avellaneda.clases.Alumno;

public class Principal {
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        String opcion;
        final int MAX = 10;
        int contador = 0;

        Alumno[] alumnos = new Alumno[MAX];
        do {
            System.out.println("1. Añadir alumno");
            System.out.println("Editar alumno");
            System.out.println("3. Listar alumnos con sus módulos y calificaciones");
            opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    if (contador < alumnos.length) {
                        alumnos[contador] = addAlumno();
                        contador++;

                    } else {
                        System.out.println("No se pueden añadir más alumnos");
                    }

                    break;
                case "3":
                    mostrarAlumnos(alumnos);
                    break;
                default:
                    break;
            }

        } while (!opcion.equalsIgnoreCase("S"));

    }

    private static void mostrarAlumnos(Alumno[] alumnos) {
        for (Alumno a : alumnos) {
            if (a != null) {
                System.out.println(a.mostrarInformacion());
            }
        }

    }

    private static Alumno addAlumno() {
        Alumno alumno;
        String nombre, matricula;
        System.out.println("Nombre");
        nombre = sc.nextLine();
        System.out.println("Matricula");
        matricula = sc.nextLine();
        alumno = new Alumno(nombre, matricula);

        return alumno;

    }

}
