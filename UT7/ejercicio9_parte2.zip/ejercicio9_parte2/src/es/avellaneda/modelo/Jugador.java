package es.avellaneda.modelo;

import java.util.List;

public class Jugador implements Evaluable {

    private String nombre;
    private List<DeporteInvierno> deportes;

    public Jugador(String nombre, List<DeporteInvierno> deportes) {
        this.nombre = nombre;
        this.deportes = deportes;
    }

    @Override
    public double calcularPuntuacion() {

        // recorrer la lista de DeporteInvierno
        double puntuacion = 0;
        for (DeporteInvierno d : deportes) {
            puntuacion += d.calcularPuntuacion();
        }
        return puntuacion;
    }

    public void mostrarInfo() {
        System.out.println("Jugador: " + nombre);
        System.out.println("Deportes que participa:");
        for(DeporteInvierno d : deportes) {
            System.out.println(" - " + d.getNombre() + ": " + d.calcularPuntuacion() + " pts");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}
