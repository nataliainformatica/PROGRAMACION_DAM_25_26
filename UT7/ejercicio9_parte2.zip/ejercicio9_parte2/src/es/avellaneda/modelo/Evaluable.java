package es.avellaneda.modelo;

public interface Evaluable {
    double calcularPuntuacion();
}