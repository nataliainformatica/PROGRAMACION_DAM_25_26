package es.avellaneda.modelo;

import java.util.List;

public class EquipoRelevo implements Evaluable {

    private String nombreEquipo;
    private List<Jugador> jugadores;

    public EquipoRelevo(String nombreEquipo, List<Jugador> jugadores) {
        this.nombreEquipo = nombreEquipo;
        this.jugadores = jugadores;
    }

    @Override
    public double calcularPuntuacion() {
        // recorrer la lista de jugadores, sumando sus puntuaciones
        double puntuacion=0; 
        for(Jugador j : jugadores) {
            puntuacion += j.calcularPuntuacion(); 
        }
        return puntuacion; 

    }

    public void mostrarInfo() {
        System.out.println("Equipo de Relevo: " + nombreEquipo);
        System.out.println("Jugadores:");
        for(Jugador j : jugadores) {
            System.out.println(" - " + j.getNombre() + ": " + j.calcularPuntuacion() + " pts");
        }
    }
}
