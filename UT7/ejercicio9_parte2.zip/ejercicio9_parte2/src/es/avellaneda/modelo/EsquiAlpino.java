package es.avellaneda.modelo;
public class EsquiAlpino extends DeporteInvierno {

    private double tiempoSegundos;
    private int penalizaciones;

    public EsquiAlpino(String nombre, int numParticipantes,
                       double tiempoSegundos, int penalizaciones) {
        super(nombre, numParticipantes);
        this.tiempoSegundos = tiempoSegundos;
        this.penalizaciones = penalizaciones;
    }

    @Override
    public double calcularPuntuacion() {
        return 100 - tiempoSegundos - (penalizaciones * 5);
    }

    public double getTiempoSegundos() {
        return tiempoSegundos;
    }

    public int getPenalizaciones() {
        return penalizaciones;
    }

    
}
