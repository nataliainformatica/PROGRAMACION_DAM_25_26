package es.avellaneda.modelo;
public class PatinajeArtistico extends DeporteInvierno {

    private double dificultad;
    private double ejecucion;

    public PatinajeArtistico(String nombre, int numParticipantes,
                             double dificultad, double ejecucion) {
        super(nombre, numParticipantes);
        this.dificultad = dificultad;
        this.ejecucion = ejecucion;
    }

    @Override
    public double calcularPuntuacion() {
        return dificultad * 0.6 + ejecucion * 0.4;
    }
    
}
