package es.avellaneda.modelo;
public abstract class DeporteInvierno {

    protected String nombre;
    protected int numParticipantes;

    public DeporteInvierno(String nombre, int numParticipantes) {
        this.nombre = nombre;
        this.numParticipantes = numParticipantes;
    }

    public abstract double calcularPuntuacion();

    public void mostrarInfo() {
        System.out.println("Deporte: " + nombre);
        System.out.println("Participantes: " + numParticipantes);
    }
}
