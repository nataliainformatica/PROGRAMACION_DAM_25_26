package es.avellaneda.principal;
import java.util.ArrayList;
import es.avellaneda.modelo.*;

public class OlimpiadasApp {

    public static void main(String[] args) {

        ArrayList<DeporteInvierno> pruebas = new ArrayList<>();

        pruebas.add(new PatinajeArtistico("Final femenina", 12, 9.5, 9.0));
        pruebas.add(new EsquiAlpino("Descenso masculino", 30, 82.3, 1));
        pruebas.add(new PatinajeArtistico("Parejas", 8, 8.7, 9.2));

        for (DeporteInvierno d : pruebas) {
            d.mostrarInfo();
            System.out.println("Puntuación: " + d.calcularPuntuacion());
            System.out.println("----------------------");
        }
    }
}