package es.avellaneda.principal;

import java.util.Scanner;

import es.avellaneda.utilidades.Utilidades;

/**
 * En en programa que debes realizar en este ejercicio, simularemos la encuesta,
 * mostrando por consola al ususario 10 preguntas. Las preguntas se facilitan en
 * la clase Utilidades, mediante el método public static String[]
 * devolverPreguntas(){….}, que como podrás observar devuelve un array de
 * String, y cada posición del array es una pregunta de la encuesta.
 * 
 * 
 */
public class principal {
    public static void main(String[] args) {
        int[] respuestas;
        String[] preguntas = Utilidades.devolverPreguntas();
        // en el array tengo la colección de preguntas
        respuestas = realizarEncuesta(preguntas);
        mostrarResultados(preguntas, respuestas);

        segundaParte(preguntas, Utilidades.getEncuestas());

    }

    private static int[] realizarEncuesta(String[] preguntas) {
        int[] respuestas = new int[preguntas.length];

        System.out.println("PREGUNTAS DE LA ENCUESTA");

        for (int i = 0; i < preguntas.length; i++) {
            System.out.println("PREGUNTA Nº : " + (i + 1) + ": " + preguntas[i]);
            System.out.println("Responde de 1 a 5");
            respuestas[i] = introduceNumero();
        }

        return respuestas;

    }

    /**
     * Si no se introduce un número (es decir, se escribe una letra u otro
     * caracter), se valorará la pregunta como un CERO Si se introduce cualquier
     * otro valor que no sea del 1 al 5, también se valorará como un CERO.
     */
    private static int introduceNumero() {
        Scanner sc = new Scanner(System.in);

        int numero = 0;
        try {
            numero = sc.nextInt();

            if (numero > 5 || numero < 1) {
                return 0;
            }
        } catch (Exception e) {
            //
            return 0;
        }
        return numero;

    }

    /**
     * Realiza una función que calcule la nota media de cada pregunta, para calcular
     * la nota media, solo se tendrán en cuenta las preguntas contestadas
     * adecuadamente (con valores de 1 a 5).
     */

    private static int calcularMedia(int[] notas) {

        int notaMedia = 0;
        int acumulador = 0;
        int contador = 0; // para los valores válidos

        for (int i = 0; i < notas.length; i++) {
            if (notas[i] != 0) {
                acumulador = acumulador + notas[i];
                contador++;
            }
            notaMedia = acumulador / contador;
        }

        return notaMedia;

    }

    private static void mostrarResultados(String[] preguntas, int[] respuestas) {

        for (int i = 0; i < preguntas.length; i++) {

            System.out.println(preguntas[i] + ": " + respuestas[i]);

        }

        System.out.println("La nota media es " + calcularMedia(respuestas));
        // completar

    }

    /**
     * Debes crear el código, para hacer la media cada una de las preguntas (con
     * todos los resultados), de forma que se pueda mostrar el resultado
     */
    private static void segundaParte(String[] preguntas, int[][] notas) {

        // preguntas
        // notas
        // cada pregunta es una columna del bidimensional
        int[] resultados = new int[notas[0].length];
        for (int col = 0; col < notas[0].length; col++) {

            // para cada columna, quiero sumar todas las filas
            int acumulador = 0;
            for (int fila = 0; fila < notas.length; fila++) {
                acumulador += notas[fila][col];
                // para cada una de las columnas, se acumulan todas las filas
            }
            // al finalizar, guardo el valor del acumulador en un array de resultados
            resultados[col] = acumulador / notas.length;
        }
        // en este punto ya tenemos los resultados y podríamos mostrarlos


        for( int i=0; i< preguntas.length; i++){
            System.out.println("La media de la pregunta " + (i+1) + " es : " + resultados[i]);
        }

    }

}
