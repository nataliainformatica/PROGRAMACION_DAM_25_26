package principal;

import java.util.Scanner;

import modelo.DAO;
import modelo.Participante;

public class App {
    private static Scanner sc = new Scanner(System.in);
    private static final String SALIR = "7";
    private static DAO dao; 

    public static void main(String[] args) throws Exception {
        dao = new DAO(); 

        String opcion="";

        do {
            try{
            menu();
            opcion = sc.nextLine();
            switch (opcion) {
                case "1":
                    // registrar participante
                    if(registrarParticipante()){
                        System.out.println("Participante registrado");
                    }else{
                        System.out.println("Ha ocurrido un error, vuelve a intentarlo");
                    }
                    break;
                case "2": 
                    // mostrar participantes registrados
                    System.out.println(dao.listarRegistrados());
                    
                break; 
                case "3":
                    //confirmar asistencia al evento
                    if(confirmarAsistencia()){
                        // TODO MOSTRAR MENSAJE - NOS QUEDAMOS AQUÍ
                    };
                    break;

                default:
                    break;
            }
            }catch(Exception e){
                // TODO - tratamiento de las posibles excepciones
                // inputMistmatch
                System.out.println("No has introducido valores válidos");

            }
        } while (!opcion.equals(SALIR));
    }

    private static void menu() {

        System.out.println("1.Registrar participante");
        System.out.println("2. Mostrar participantes registrados");
        System.out.println("3.");
        System.out.println("4.");
        System.out.println("5.");
        System.out.println("6.");
        System.out.println("7.");

    }
    private static boolean confirmarAsistencia(){
        Participante p; 
        System.out.println("Introduce el número de participante");
         // con el número es necesario buscar el participante en "registrados"
         p =dao.buscarParticipanteRegistrado(sc.nextInt());
         // si se introduce un valor no válido se propagará la excepcion (RunTime)
        if(p!= null){
            // añadir Participante a asistentesEvento
            dao.registrarAsistencia(p); 
            return true; 

        }else{
            System.out.println("Participante no registrado");
        }
        return false; 
       
    }
    private static boolean registrarParticipante() {
        String nombre, email;
        System.out.println("Introduce el nombre");
        nombre = sc.nextLine();
        System.out.println("Introduce el email");
        email = sc.nextLine();


        return true;

    }
}
