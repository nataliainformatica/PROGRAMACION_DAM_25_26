package modelo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class DAO {


    private  List<Participante> registrados; 
    private Set<Participante> asistentesEvento; 
    public DAO(){
        this.registrados = new ArrayList<>();
        this.asistentesEvento = new HashSet<>(); 
    }

    public  boolean registrarParticipante(Participante p){
        // se permiten duplicados
        registrados.add(p); 
        return true; 
    }
    public String listarRegistrados(){
        if(registrados.isEmpty()){
            return "No hay participantes registrados"; 
        }
        return registrados.toString();
        }
        public Participante buscarParticipanteRegistrado(int idParticipante){
            // recorrer el arrayList y buscar el id de participante
            for(Participante p: registrados){
                if(p.getId()== idParticipante){
                    return p; 
                }
            }
            return null; 

        }
        public boolean registrarAsistencia(Participante p ){
            if(asistentesEvento.add(p)){
                return true; 
            }
            return false; 
        }

}
