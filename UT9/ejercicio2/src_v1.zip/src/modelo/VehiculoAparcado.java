package modelo;

import java.time.Duration;
import java.time.LocalTime;

import excepciones.MatriculaInvalida;

public abstract class VehiculoAparcado {

    protected String matricula;
    protected LocalTime horaEntrada;
    protected LocalTime horaSalida;
    protected boolean lavado;

    // Recibe matrícula, marca,hora de entrada.
    public VehiculoAparcado(String matricula, LocalTime horaEntrada) throws MatriculaInvalida {
        this.matricula = matricula;
        this.horaEntrada = horaEntrada;
        if (!comprobarMatricula()) {
            throw new MatriculaInvalida(matricula, horaEntrada);
        }

    }

    public VehiculoAparcado(String matricula) throws MatriculaInvalida {
        this.matricula = matricula;
        horaEntrada = LocalTime.now();
        if (!comprobarMatricula()) {
            throw new MatriculaInvalida(matricula, horaEntrada);
        }
    }

    private boolean comprobarMatricula() {
        return matricula.matches("\\d{4}[A-Z]{3}");

    }
    public void finalizarAparcamiento(){
        if(horaSalida != null){
            horaSalida = LocalTime.now(); 
        }
    }

    // métodos
    public String mostrarInformacion() {
        StringBuilder sb = new StringBuilder();
        sb.append("Matricula " + matricula);
        sb.append("Hora de Entrada: " + horaEntrada.toString());
        sb.append("Hora de Salida: " + horaSalida.toString());
        return sb.toString();
    }

    protected long calcularHorasFacturables() {
        return Duration.between(horaSalida, horaEntrada).toHours();
    }
    public abstract double calcularPrecioParking();

    public String getMatricula() {
        return matricula;
    }

    public LocalTime getHoraEntrada() {
        return horaEntrada;
    }

    public LocalTime getHoraSalida() {
        return horaSalida;
    }

    public boolean isLavado() {
        return lavado;
    }

    @Override
    public String toString() {
        return "VehiculoAparcado [matricula=" + matricula + ", horaEntrada=" + horaEntrada + ", horaSalida="
                + horaSalida + ", lavado=" + lavado + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((matricula == null) ? 0 : matricula.hashCode());
        result = prime * result + ((horaSalida == null) ? 0 : horaSalida.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        VehiculoAparcado other = (VehiculoAparcado) obj;
        if (matricula == null) {
            if (other.matricula != null)
                return false;
        } else if (!matricula.equals(other.matricula))
            return false;
        if (horaSalida == null) {
            if (other.horaSalida != null)
                return false;
        } else if (!horaSalida.equals(other.horaSalida))
            return false;
        return true;
    }

    // añado toString
    // defino equals, por matrícula

    

}
