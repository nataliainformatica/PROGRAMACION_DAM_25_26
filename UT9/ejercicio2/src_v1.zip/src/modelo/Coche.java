package modelo;

import java.time.LocalTime;

import excepciones.MatriculaInvalida;

public class Coche extends VehiculoAparcado implements Lavable {
    private int numeroPuertas;
    private boolean esSuv;

     public Coche(String matricula ,int numeroPuertas, boolean esSuv) throws MatriculaInvalida {
        super(matricula);
        this.numeroPuertas = numeroPuertas;
        this.esSuv = esSuv;
    }

    public Coche(String matricula, LocalTime horaEntrada, int numeroPuertas, boolean esSuv) throws MatriculaInvalida {
        super(matricula, horaEntrada);
        this.numeroPuertas = numeroPuertas;
        this.esSuv = esSuv;
    }
    


    /*
     * Implementación de calcularPrecioParking():
     * 
     * Precio base: 2.5 €/hora Si es SUV: +20% al precio Si lavado == true: se
     * descuentan 2 horas
     * 
     * 
     */
    @Override
    public double calcularPrecioParking() {
        // calcular horas - método heredado
        double  precio= calcularHorasFacturables()*2.5; 
        if(esSuv){
            precio = precio*1.2;
        }
        if(lavado){
            precio = precio -2; 
        }
        return precio; 

    }
    /*
     * Implementación de Lavable:
     * 
     * Precio lavado: 12 €
     */
    @Override
    public double calcularPrecioLavado() {
        return 12; 
    }
    public int getNumeroPuertas() {
        return numeroPuertas;
    }

    public void setNumeroPuertas(int numeroPuertas) {
        this.numeroPuertas = numeroPuertas;
    }

    public boolean isEsSuv() {
        return esSuv;
    }

    public void setEsSuv(boolean esSuv) {
        this.esSuv = esSuv;
    }



}
