package modelo;

public interface Lavable {
    double calcularPrecioLavado();

}
