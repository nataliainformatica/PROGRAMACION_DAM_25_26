package modelo;

import java.time.LocalTime;

import excepciones.MatriculaInvalida;

public class Moto extends VehiculoAparcado implements Lavable{
    private int cilindrada;
    public Moto(String matricula, int cilindrada) throws MatriculaInvalida {
        super(matricula);
        this.cilindrada = cilindrada; 
    }

  public Moto(String matricula, LocalTime horaEntrada, int cilindrada) throws MatriculaInvalida {
        super(matricula, horaEntrada);
        this.cilindrada = cilindrada; 
    }
    /*
    Implementación de calcularPrecioParking():

Precio base: 1.5 €/hora Si lavado == true: se descuentan 2 horas */
     @Override
    public double calcularPrecioParking() {
        // calcular horas - método heredado
        double  precio= calcularHorasFacturables()*2; 
      
        if(lavado){
            precio = precio -2; 
        }
        return precio; 

    }
    @Override
    public double calcularPrecioLavado() {
               return 5; 
    }



    
}
