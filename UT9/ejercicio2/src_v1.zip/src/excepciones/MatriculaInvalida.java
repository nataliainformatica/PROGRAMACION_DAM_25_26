package excepciones;

import java.time.LocalTime;

public class MatriculaInvalida extends Exception{
    private String matricula;
    private LocalTime hora;
    public MatriculaInvalida(String matricula, LocalTime hora) {
        this.matricula = matricula;
        this.hora = hora;
    }
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    public LocalTime getHora() {
        return hora;
    }
    public void setHora(LocalTime hora) {
        this.hora = hora;
    }
    

    

}
